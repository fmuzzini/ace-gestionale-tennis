var searchData=
[
  ['lista_5fcampi',['lista_campi',['../struttura__dati_8h.html#a7b0ec232639e878f55aaf0698a30de79',1,'struttura_dati.h']]],
  ['lista_5fgiocatori',['lista_giocatori',['../struttura__dati_8h.html#a2ce396e44bb6d2fe43daf5ed28611266',1,'struttura_dati.h']]],
  ['lista_5fore',['lista_ore',['../struttura__dati_8h.html#a9d6ea45de8f2a4276f4e6ecd19e8d80e',1,'struttura_dati.h']]]
];
