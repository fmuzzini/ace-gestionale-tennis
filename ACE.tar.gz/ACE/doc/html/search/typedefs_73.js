var searchData=
[
  ['stringa',['stringa',['../struttura__dati_8h.html#adc042033824a4d30262dea3d11937921',1,'struttura_dati.h']]]
];
