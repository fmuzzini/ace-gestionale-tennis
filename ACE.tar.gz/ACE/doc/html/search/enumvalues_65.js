var searchData=
[
  ['erba',['ERBA',['../struttura__dati_8h.html#a0c12af1750520ca1d5e0a1b120ed33b7a772329657a044e6e767b6016feb1e23c',1,'struttura_dati.h']]],
  ['erba_5fsintetica',['ERBA_SINTETICA',['../struttura__dati_8h.html#a0c12af1750520ca1d5e0a1b120ed33b7a05a72952ce3fe2b329035258407741bb',1,'struttura_dati.h']]]
];
