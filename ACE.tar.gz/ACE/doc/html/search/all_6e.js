var searchData=
[
  ['n_5fcampi',['n_campi',['../structcircolo__t.html#ad936c96509d0ba268f3fba9ce0157222',1,'circolo_t']]],
  ['n_5fsoci',['n_soci',['../structcircolo__t.html#aa22213a01ed8b0e7d612bdf815db337f',1,'circolo_t']]],
  ['nascita',['nascita',['../structgiocatore__t.html#a22cdca2a4d519bfbd64649d4f4cb266f',1,'giocatore_t']]],
  ['nascondi_5ffinestra',['nascondi_finestra',['../handler_8cc.html#a3cea95cc33a7419edc4bc03872da2c2c',1,'nascondi_finestra(GtkWidget *widget, GdkEvent *event, gpointer user_data):&#160;handler.cc'],['../handler_8h.html#a3cea95cc33a7419edc4bc03872da2c2c',1,'nascondi_finestra(GtkWidget *widget, GdkEvent *event, gpointer user_data):&#160;handler.cc']]],
  ['nome',['nome',['../structcircolo__t.html#aa697bc3b2bef882ea48ca71972765d03',1,'circolo_t::nome()'],['../structgiocatore__t.html#ac3f1b0dcd6f3439adbc2e86db6bea952',1,'giocatore_t::nome()']]],
  ['note',['note',['../structcampo__t.html#aada0759d9033cc156fbea6ef35a272e0',1,'campo_t']]],
  ['numero',['numero',['../structcampo__t.html#a6e0a6002a8c0d360f22d4a30bc1e37d0',1,'campo_t']]]
];
