var searchData=
[
  ['operator_3e_3e',['operator&gt;&gt;',['../file__IO_8cc.html#af38d16c9199443fd7c34b26fa2d4e7e0',1,'operator&gt;&gt;(istream &amp;is, copertura_t &amp;c):&#160;file_IO.cc'],['../file__IO_8cc.html#ac4ff66902af0718f2e7ee39fe55a71f3',1,'operator&gt;&gt;(istream &amp;is, terreno_t &amp;t):&#160;file_IO.cc']]]
];
