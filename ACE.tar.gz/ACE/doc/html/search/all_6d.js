var searchData=
[
  ['main',['main',['../ACE_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'ACE.cc']]],
  ['mostra_5ffinestra',['mostra_finestra',['../handler_8cc.html#abef113ade0ebf32552faf22013fb51e6',1,'mostra_finestra(GtkMenuItem *actived, gpointer finestra):&#160;handler.cc'],['../handler_8h.html#abef113ade0ebf32552faf22013fb51e6',1,'mostra_finestra(GtkMenuItem *actived, gpointer finestra):&#160;handler.cc']]]
];
