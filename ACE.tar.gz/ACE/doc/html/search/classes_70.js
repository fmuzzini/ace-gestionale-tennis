var searchData=
[
  ['parametro_5ft',['parametro_t',['../structparametro__t.html',1,'']]]
];
