var searchData=
[
  ['telefono',['telefono',['../structcircolo__t.html#a7943de242b2ed1b21f02e055097e6576',1,'circolo_t::telefono()'],['../structgiocatore__t.html#a7666d4d5062f1c86860a2fbc41ba1042',1,'giocatore_t::telefono()']]],
  ['terreni',['terreni',['../handler_8cc.html#a951a8018f2da583e7a03b930fc58e237',1,'handler.cc']]],
  ['terreno',['terreno',['../structcampo__t.html#ab875e984264bf393977eb07cfe2f7341',1,'campo_t']]],
  ['tessera',['tessera',['../structgiocatore__t.html#aed14cc86d81c10cf2cc50165cfc5a59f',1,'giocatore_t']]]
];
