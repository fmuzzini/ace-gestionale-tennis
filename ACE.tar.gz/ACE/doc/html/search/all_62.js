var searchData=
[
  ['backup',['backup',['../file__IO_8cc.html#a6b5cce7059635c9b27474d6b4d54d4f6',1,'backup(const char file[], circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#a6b5cce7059635c9b27474d6b4d54d4f6',1,'backup(const char file[], circolo_t *circolo):&#160;file_IO.cc']]],
  ['backup_5fdir',['backup_dir',['../file__IO_8cc.html#a6e2db1940f05de9ecb47aabc582f21ad',1,'file_IO.cc']]],
  ['backup_5ffile',['backup_file',['../file__IO_8cc.html#a8d9c9967c67e1748ed3abc168fd0387a',1,'file_IO.cc']]],
  ['build',['build',['../ACE_8cc.html#a25e58c3375b9bff39382bbe4c77c9355',1,'build():&#160;ACE.cc'],['../handler_8cc.html#a25e58c3375b9bff39382bbe4c77c9355',1,'build():&#160;ACE.cc']]]
];
