var searchData=
[
  ['operator_3e_3e',['operator&gt;&gt;',['../file__IO_8cc.html#af38d16c9199443fd7c34b26fa2d4e7e0',1,'operator&gt;&gt;(istream &amp;is, copertura_t &amp;c):&#160;file_IO.cc'],['../file__IO_8cc.html#ac4ff66902af0718f2e7ee39fe55a71f3',1,'operator&gt;&gt;(istream &amp;is, terreno_t &amp;t):&#160;file_IO.cc']]],
  ['ora_5fapertura',['ORA_APERTURA',['../handler_8cc.html#afd4f3203e7d93c11312acfb3bd818b4d',1,'handler.cc']]],
  ['ora_5fchiusura',['ORA_CHIUSURA',['../handler_8cc.html#af45dc783e55c4fd9bcebf41135fe5da9',1,'handler.cc']]],
  ['ora_5ft',['ora_t',['../structora__t.html',1,'']]],
  ['orario',['orario',['../structora__t.html#aa0a139446f6b1e6d08ad37d2f7de8125',1,'ora_t']]],
  ['ore',['ore',['../structcampo__t.html#aab5d62794b2dd7a9ca1b2db014d70702',1,'campo_t']]],
  ['ore_5fdir',['ORE_DIR',['../file__IO_8cc.html#a5da5b71bb34d1b4eed8ed9eb40e3f682',1,'file_IO.cc']]],
  ['outdoor',['OUTDOOR',['../struttura__dati_8h.html#ad0f5a2191c29d4cd4c52506513493755a8c38e218bbbd030490bf90a71baad2b9',1,'struttura_dati.h']]]
];
