var searchData=
[
  ['d1',['D1',['../debug_8h.html#afff1e38d74b3116b7a77d0272adf2dbf',1,'debug.h']]],
  ['d2',['D2',['../debug_8h.html#a43e8ca05b2c0abb00d31e535b4186b7e',1,'debug.h']]],
  ['data',['data',['../structora__t.html#a39c8c649c092efd6aa20c0f9bb6bc437',1,'ora_t']]],
  ['data_5fpath',['DATA_PATH',['../file__IO_8cc.html#a4498167a41f7467a5dddeb2bfaea59b6',1,'DATA_PATH():&#160;file_IO.cc'],['../handler_8cc.html#a4498167a41f7467a5dddeb2bfaea59b6',1,'DATA_PATH():&#160;handler.cc']]],
  ['dati_5fcampo',['DATI_CAMPO',['../file__IO_8cc.html#a99f3c14c7a2142b632d6fe6ecdf09f6d',1,'file_IO.cc']]],
  ['dati_5fcircolo',['DATI_CIRCOLO',['../file__IO_8cc.html#a5a1a7a8b73922583ea389cdc7b12575c',1,'file_IO.cc']]],
  ['dbg',['DBG',['../debug_8h.html#a9fd176efd6d22cb809550f0271c2a93d',1,'debug.h']]],
  ['dealloca_5fora',['dealloca_ora',['../accesso__dati_8cc.html#a3920fd417a14ad5a648b725ad941c4bb',1,'accesso_dati.cc']]],
  ['debug_2eh',['debug.h',['../debug_8h.html',1,'']]],
  ['disegna_5ftabella_5fore',['disegna_tabella_ore',['../handler_8cc.html#a952e1263d42c2a3e4df7cb4189d52379',1,'disegna_tabella_ore():&#160;handler.cc'],['../handler_8h.html#a952e1263d42c2a3e4df7cb4189d52379',1,'disegna_tabella_ore():&#160;handler.cc']]],
  ['distruggi_5fcella_5fse_5finterna',['distruggi_cella_se_interna',['../handler_8cc.html#ac8a9536dc4693a966d4e0023e4d745c6',1,'handler.cc']]],
  ['durata',['durata',['../structora__t.html#abd8b8cd2025d6d097f5a415868ccbd68',1,'ora_t']]]
];
