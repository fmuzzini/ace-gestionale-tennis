var searchData=
[
  ['nascondi_5ffinestra',['nascondi_finestra',['../handler_8cc.html#a3cea95cc33a7419edc4bc03872da2c2c',1,'nascondi_finestra(GtkWidget *widget, GdkEvent *event, gpointer user_data):&#160;handler.cc'],['../handler_8h.html#a3cea95cc33a7419edc4bc03872da2c2c',1,'nascondi_finestra(GtkWidget *widget, GdkEvent *event, gpointer user_data):&#160;handler.cc']]]
];
