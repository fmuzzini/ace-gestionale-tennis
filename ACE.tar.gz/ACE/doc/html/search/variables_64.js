var searchData=
[
  ['data',['data',['../structora__t.html#a39c8c649c092efd6aa20c0f9bb6bc437',1,'ora_t']]],
  ['data_5fpath',['DATA_PATH',['../file__IO_8cc.html#a4498167a41f7467a5dddeb2bfaea59b6',1,'DATA_PATH():&#160;file_IO.cc'],['../handler_8cc.html#a4498167a41f7467a5dddeb2bfaea59b6',1,'DATA_PATH():&#160;handler.cc']]],
  ['dati_5fcampo',['DATI_CAMPO',['../file__IO_8cc.html#a99f3c14c7a2142b632d6fe6ecdf09f6d',1,'file_IO.cc']]],
  ['dati_5fcircolo',['DATI_CIRCOLO',['../file__IO_8cc.html#a5a1a7a8b73922583ea389cdc7b12575c',1,'file_IO.cc']]],
  ['durata',['durata',['../structora__t.html#abd8b8cd2025d6d097f5a415868ccbd68',1,'ora_t']]]
];
