var searchData=
[
  ['inizializza_5fcircolo',['inizializza_circolo',['../accesso__dati_8cc.html#a5f411b92b995ff84d3acd8bc0da1191e',1,'inizializza_circolo(const char nome[], const char indirizzo[], const char email[], const char telefono[]):&#160;accesso_dati.cc'],['../accesso__dati_8h.html#a5f411b92b995ff84d3acd8bc0da1191e',1,'inizializza_circolo(const char nome[], const char indirizzo[], const char email[], const char telefono[]):&#160;accesso_dati.cc']]],
  ['inserisci_5fin_5fordine_5fcampo',['inserisci_in_ordine_campo',['../accesso__dati_8cc.html#aa5acc31c0536d43ac5d64ab9a60e540d',1,'accesso_dati.cc']]],
  ['inserisci_5fin_5fordine_5fora',['inserisci_in_ordine_ora',['../accesso__dati_8cc.html#a35c03875a1472b1da599d2d6369778f9',1,'accesso_dati.cc']]],
  ['inserisci_5fore_5fvuote',['inserisci_ore_vuote',['../handler_8cc.html#aafd920a801e75d4ca88223fb492d3ba2',1,'handler.cc']]],
  ['inserisci_5frighe_5fcampi',['inserisci_righe_campi',['../handler_8cc.html#a3dfb1abf80d66926a17e6065559ea726',1,'handler.cc']]],
  ['insert_5flist_5fcampi',['insert_list_campi',['../handler_8cc.html#a332b65c4735ded9b047d074bb8f2639b',1,'handler.cc']]],
  ['insert_5flist_5fgiocatore',['insert_list_giocatore',['../handler_8cc.html#a8bf2479da80daf509d7af3dca324e92c',1,'handler.cc']]]
];
