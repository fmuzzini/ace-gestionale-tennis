var searchData=
[
  ['terra',['TERRA',['../struttura__dati_8h.html#a0c12af1750520ca1d5e0a1b120ed33b7af716ec1950763e4a93a6a0b029dc9ca5',1,'struttura_dati.h']]]
];
