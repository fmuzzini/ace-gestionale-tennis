var searchData=
[
  ['ripristina',['ripristina',['../file__IO_8cc.html#af656044d932e2dc1a62b5a39576d1f0e',1,'ripristina(const char file[]):&#160;file_IO.cc'],['../file__IO_8h.html#af656044d932e2dc1a62b5a39576d1f0e',1,'ripristina(const char file[]):&#160;file_IO.cc']]]
];
