var searchData=
[
  ['prenotante_5ft',['prenotante_t',['../struttura__dati_8h.html#add29541da10dc64656b40be2bf60fae1',1,'struttura_dati.h']]]
];
