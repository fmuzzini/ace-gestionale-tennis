var searchData=
[
  ['giocatore_5ft',['giocatore_t',['../structgiocatore__t.html',1,'']]]
];
