var searchData=
[
  ['email',['email',['../structcircolo__t.html#acc39a66165c7378ded7ff8bcbc684135',1,'circolo_t::email()'],['../structgiocatore__t.html#a90aeb6b0953f3416e27ef9e1a121e743',1,'giocatore_t::email()']]],
  ['estensione_5fbackup',['ESTENSIONE_BACKUP',['../handler_8cc.html#a13fe06ea7d409828447a956f7e130977',1,'handler.cc']]],
  ['etx',['ETX',['../file__IO_8cc.html#a38d19e747bdb249f2c8b044ab34b1876',1,'file_IO.cc']]]
];
