var searchData=
[
  ['terreno_5ft',['terreno_t',['../struttura__dati_8h.html#a0c12af1750520ca1d5e0a1b120ed33b7',1,'struttura_dati.h']]],
  ['tipo_5fora',['tipo_ora',['../handler_8cc.html#ad2ef6a61f674ffd893c018201b796901',1,'handler.cc']]]
];
