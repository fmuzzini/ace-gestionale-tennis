var searchData=
[
  ['copertura_5ft',['copertura_t',['../struttura__dati_8h.html#ad0f5a2191c29d4cd4c52506513493755',1,'struttura_dati.h']]]
];
