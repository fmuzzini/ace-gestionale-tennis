var searchData=
[
  ['retta',['retta',['../structgiocatore__t.html#aa9cd22efd9d0fa8a1de98dafcaeacdbd',1,'giocatore_t']]],
  ['ripristina',['ripristina',['../file__IO_8cc.html#af656044d932e2dc1a62b5a39576d1f0e',1,'ripristina(const char file[]):&#160;file_IO.cc'],['../file__IO_8h.html#af656044d932e2dc1a62b5a39576d1f0e',1,'ripristina(const char file[]):&#160;file_IO.cc']]]
];
