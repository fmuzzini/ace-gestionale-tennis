var searchData=
[
  ['retta',['retta',['../structgiocatore__t.html#aa9cd22efd9d0fa8a1de98dafcaeacdbd',1,'giocatore_t']]]
];
