var searchData=
[
  ['archivio_5fdir',['ARCHIVIO_DIR',['../file__IO_8cc.html#a4e41eb5148197c7f1dd04e765e648feb',1,'file_IO.cc']]]
];
