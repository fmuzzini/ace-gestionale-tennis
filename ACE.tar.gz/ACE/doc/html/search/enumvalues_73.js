var searchData=
[
  ['sintetico',['SINTETICO',['../struttura__dati_8h.html#a0c12af1750520ca1d5e0a1b120ed33b7a6846ea149ed5fe29f199e562567a1ddb',1,'struttura_dati.h']]]
];
