var searchData=
[
  ['ora_5fapertura',['ORA_APERTURA',['../handler_8cc.html#afd4f3203e7d93c11312acfb3bd818b4d',1,'handler.cc']]],
  ['ora_5fchiusura',['ORA_CHIUSURA',['../handler_8cc.html#af45dc783e55c4fd9bcebf41135fe5da9',1,'handler.cc']]],
  ['orario',['orario',['../structora__t.html#aa0a139446f6b1e6d08ad37d2f7de8125',1,'ora_t']]],
  ['ore',['ore',['../structcampo__t.html#aab5d62794b2dd7a9ca1b2db014d70702',1,'campo_t']]],
  ['ore_5fdir',['ORE_DIR',['../file__IO_8cc.html#a5da5b71bb34d1b4eed8ed9eb40e3f682',1,'file_IO.cc']]]
];
