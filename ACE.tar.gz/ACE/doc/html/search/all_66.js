var searchData=
[
  ['file_5fext',['FILE_EXT',['../file__IO_8cc.html#ab0b03ad19de1e26bd0293def15f73d75',1,'file_IO.cc']]],
  ['file_5fio_2ecc',['file_IO.cc',['../file__IO_8cc.html',1,'']]],
  ['file_5fio_2eh',['file_IO.h',['../file__IO_8h.html',1,'']]],
  ['file_5fnascosto',['file_nascosto',['../file__IO_8cc.html#a5be4d4dad972d003a60acda0a2e90339',1,'file_nascosto(const char file[]):&#160;file_IO.cc'],['../file__IO_8h.html#a5be4d4dad972d003a60acda0a2e90339',1,'file_nascosto(const char file[]):&#160;file_IO.cc']]],
  ['finestra_5ferrore',['finestra_errore',['../handler_8cc.html#a8713b519a311ec08fc899e7fa176f963',1,'finestra_errore(const char messaggio[]):&#160;handler.cc'],['../handler_8h.html#a8713b519a311ec08fc899e7fa176f963',1,'finestra_errore(const char messaggio[]):&#160;handler.cc']]]
];
