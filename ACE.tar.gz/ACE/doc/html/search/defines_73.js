var searchData=
[
  ['stringa_5forario',['STRINGA_ORARIO',['../handler_8cc.html#a95a01084740ad1073c35012600beada7',1,'handler.cc']]]
];
