var searchData=
[
  ['prenotante',['prenotante',['../structora__t.html#aff5567fde9f9f0bdb0414e67d2bd30bf',1,'ora_t']]],
  ['prenotata',['PRENOTATA',['../handler_8cc.html#ad2ef6a61f674ffd893c018201b796901a650770b03fcc1dfe25b5dc72d7bb97e8',1,'handler.cc']]],
  ['pros_5fid',['pros_id',['../structcircolo__t.html#a75ce9d50155a8bc368a10b13f516fd27',1,'circolo_t']]]
];
