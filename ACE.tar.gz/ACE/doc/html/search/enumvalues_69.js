var searchData=
[
  ['indoor',['INDOOR',['../struttura__dati_8h.html#ad0f5a2191c29d4cd4c52506513493755ac6682081af331187c2350b6200571123',1,'struttura_dati.h']]]
];
