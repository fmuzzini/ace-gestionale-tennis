var searchData=
[
  ['carica_5fcampo',['carica_campo',['../file__IO_8cc.html#a48aa2e48d9f514715dfb3e0426874085',1,'carica_campo(const char file[], circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#a48aa2e48d9f514715dfb3e0426874085',1,'carica_campo(const char file[], circolo_t *circolo):&#160;file_IO.cc']]],
  ['carica_5fcircolo',['carica_circolo',['../file__IO_8cc.html#ae58c887a1fc340538de88e9c46ff3100',1,'carica_circolo(const char nome[]):&#160;file_IO.cc'],['../file__IO_8h.html#ae58c887a1fc340538de88e9c46ff3100',1,'carica_circolo(const char nome[]):&#160;file_IO.cc']]],
  ['carica_5fgiocatore',['carica_giocatore',['../file__IO_8cc.html#ad16db5f64f651d7614e4b39e29289c88',1,'carica_giocatore(const char file[], circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#ad16db5f64f651d7614e4b39e29289c88',1,'carica_giocatore(const char file[], circolo_t *circolo):&#160;file_IO.cc']]],
  ['carica_5fora',['carica_ora',['../file__IO_8cc.html#a6a67616e7c83305dc149ecbfe9e3554f',1,'carica_ora(char file[], campo_t *campo, circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#a6a67616e7c83305dc149ecbfe9e3554f',1,'carica_ora(char file[], campo_t *campo, circolo_t *circolo):&#160;file_IO.cc']]],
  ['circolo_5fesistente',['circolo_esistente',['../file__IO_8cc.html#a51256bf33628453f9e0e7c99b76e7374',1,'circolo_esistente(const char *nome_cir):&#160;file_IO.cc'],['../file__IO_8h.html#a51256bf33628453f9e0e7c99b76e7374',1,'circolo_esistente(const char *nome_cir):&#160;file_IO.cc']]],
  ['confronta_5fdata',['confronta_data',['../accesso__dati_8cc.html#ab774400a4017e261feb47c49d7fb30c2',1,'accesso_dati.cc']]],
  ['controlla_5fdirectory',['controlla_directory',['../file__IO_8cc.html#aac1855264c07df3797f68fe2e8c92600',1,'file_IO.cc']]],
  ['controlla_5fdisponibilita_5fora',['controlla_disponibilita_ora',['../handler_8cc.html#a1f004e54cac4b7773c81f83c79e8999a',1,'handler.cc']]],
  ['controlla_5fformato_5fora',['controlla_formato_ora',['../handler_8cc.html#aa1ebd22d0b9b412732437f261124f538',1,'handler.cc']]],
  ['controllo_5festensione',['controllo_estensione',['../handler_8cc.html#a5cd77391ccb43a307314fc973742ed31',1,'handler.cc']]]
];
