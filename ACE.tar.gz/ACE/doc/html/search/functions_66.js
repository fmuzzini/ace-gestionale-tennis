var searchData=
[
  ['file_5fnascosto',['file_nascosto',['../file__IO_8cc.html#a5be4d4dad972d003a60acda0a2e90339',1,'file_nascosto(const char file[]):&#160;file_IO.cc'],['../file__IO_8h.html#a5be4d4dad972d003a60acda0a2e90339',1,'file_nascosto(const char file[]):&#160;file_IO.cc']]],
  ['finestra_5ferrore',['finestra_errore',['../handler_8cc.html#a8713b519a311ec08fc899e7fa176f963',1,'finestra_errore(const char messaggio[]):&#160;handler.cc'],['../handler_8h.html#a8713b519a311ec08fc899e7fa176f963',1,'finestra_errore(const char messaggio[]):&#160;handler.cc']]]
];
