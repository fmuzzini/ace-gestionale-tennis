var searchData=
[
  ['get_5fcurrent_5fname',['get_current_name',['../handler_8cc.html#a516736f14e3e848624813322492e3561',1,'handler.cc']]],
  ['get_5fdir_5fcampo',['get_dir_campo',['../file__IO_8cc.html#a44e4811fccd8c6536e391767ec5159af',1,'file_IO.cc']]],
  ['get_5fdir_5fcircolo',['get_dir_circolo',['../file__IO_8cc.html#aa82e7288bfea5165a7d63b66eaea48d5',1,'get_dir_circolo(const char *nome_cir):&#160;file_IO.cc'],['../file__IO_8h.html#aa82e7288bfea5165a7d63b66eaea48d5',1,'get_dir_circolo(const char *nome_cir):&#160;file_IO.cc']]],
  ['get_5fdir_5fgiocatore',['get_dir_giocatore',['../file__IO_8cc.html#a46e5fbfc2de2a13577465c4714f9f92c',1,'file_IO.cc']]],
  ['get_5fdir_5fora',['get_dir_ora',['../file__IO_8cc.html#a03b8142b4f95d1627df5e0f52e53f6ca',1,'file_IO.cc']]],
  ['get_5ffile_5fcampo',['get_file_campo',['../file__IO_8cc.html#acfd577bf437af73a5b4e83d32911a9f6',1,'file_IO.cc']]],
  ['get_5ffile_5fcircolo',['get_file_circolo',['../file__IO_8cc.html#ab55bf4cf291db643b75f0bcfeb2bc2c9',1,'file_IO.cc']]],
  ['get_5ffile_5fgiocatore',['get_file_giocatore',['../file__IO_8cc.html#a9c562f044dccef37a99e8301cddfe32f',1,'file_IO.cc']]],
  ['get_5ffile_5fora',['get_file_ora',['../file__IO_8cc.html#a8a13d72c3cb10a5bf8b1397b0dc17c5e',1,'file_IO.cc']]],
  ['get_5fnome_5fbackup',['get_nome_backup',['../file__IO_8cc.html#a76f8fd85c112dc80647fa4892339570c',1,'get_nome_backup(const char file[]):&#160;file_IO.cc'],['../file__IO_8h.html#a76f8fd85c112dc80647fa4892339570c',1,'get_nome_backup(const char file[]):&#160;file_IO.cc']]],
  ['get_5fnome_5fora',['get_nome_ora',['../accesso__dati_8cc.html#ac8878839cd059af1d8b17b2a466914b5',1,'get_nome_ora(ora_t *ora):&#160;accesso_dati.cc'],['../accesso__dati_8h.html#ac8878839cd059af1d8b17b2a466914b5',1,'get_nome_ora(ora_t *ora):&#160;accesso_dati.cc']]],
  ['get_5fstringa_5fdata',['get_stringa_data',['../handler_8cc.html#a3b9e5487e0942b6b558d5b19a39fbc2d',1,'handler.cc']]],
  ['giocatore_5ft',['giocatore_t',['../structgiocatore__t.html',1,'']]],
  ['giocatori',['giocatori',['../structcircolo__t.html#aa17088e0fc000cfbc4c6b08c0c18cef2',1,'circolo_t']]],
  ['giocatori_5fdir',['GIOCATORI_DIR',['../file__IO_8cc.html#a113e87d03f38fe75cedb3d5709ae9282',1,'file_IO.cc']]]
];
