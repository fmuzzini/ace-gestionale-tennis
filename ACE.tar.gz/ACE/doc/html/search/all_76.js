var searchData=
[
  ['vuota',['VUOTA',['../handler_8cc.html#ad2ef6a61f674ffd893c018201b796901a103e268eeab0324c0d636174572035c5',1,'handler.cc']]]
];
