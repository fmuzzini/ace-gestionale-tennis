var searchData=
[
  ['campi',['campi',['../structcircolo__t.html#ac09c9e7d077f71951c457652a874565f',1,'circolo_t']]],
  ['campi_5fdir',['CAMPI_DIR',['../file__IO_8cc.html#a2ff7122334a9754353adef957ff1007f',1,'file_IO.cc']]],
  ['circolo',['circolo',['../structgiocatore__t.html#a5275e8614d0c0d2270d0cf9929214ebf',1,'giocatore_t::circolo()'],['../handler_8cc.html#afdb5d4cc28256fee3f79b189c6a6ef58',1,'circolo():&#160;handler.cc']]],
  ['classifica',['classifica',['../structgiocatore__t.html#abac0936681f2728909612be2f0e47a46',1,'giocatore_t']]],
  ['cognome',['cognome',['../structgiocatore__t.html#ad02b92861fc7ee234cad9bb5a730a408',1,'giocatore_t']]],
  ['copertura',['copertura',['../structcampo__t.html#a98a13af547edea0107d7def51feeb923',1,'campo_t']]],
  ['coperture',['coperture',['../handler_8cc.html#a8333082ae85ce61a16c133d8da371716',1,'handler.cc']]]
];
