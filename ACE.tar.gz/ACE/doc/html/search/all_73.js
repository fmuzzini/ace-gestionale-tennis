var searchData=
[
  ['salva_5fcampo',['salva_campo',['../file__IO_8cc.html#a1946bbd82e8da6a23d39f144da47261c',1,'salva_campo(const campo_t *campo, const circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#a1946bbd82e8da6a23d39f144da47261c',1,'salva_campo(const campo_t *campo, const circolo_t *circolo):&#160;file_IO.cc']]],
  ['salva_5fcircolo',['salva_circolo',['../file__IO_8cc.html#a09f4d48bb1bddd3b628ba62f8d276c49',1,'salva_circolo(const circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#a09f4d48bb1bddd3b628ba62f8d276c49',1,'salva_circolo(const circolo_t *circolo):&#160;file_IO.cc']]],
  ['salva_5fgiocatore',['salva_giocatore',['../file__IO_8cc.html#aef6d85bdb65df00e55be504b21ea5a12',1,'salva_giocatore(const giocatore_t *giocatore, const circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#aef6d85bdb65df00e55be504b21ea5a12',1,'salva_giocatore(const giocatore_t *giocatore, const circolo_t *circolo):&#160;file_IO.cc']]],
  ['salva_5fora',['salva_ora',['../file__IO_8cc.html#ab7a55ef58177bf8857c1d1121ce6c637',1,'salva_ora(const ora_t *ora, const campo_t *campo, const circolo_t *circolo):&#160;file_IO.cc'],['../file__IO_8h.html#ab7a55ef58177bf8857c1d1121ce6c637',1,'salva_ora(const ora_t *ora, const campo_t *campo, const circolo_t *circolo):&#160;file_IO.cc']]],
  ['set_5factive',['set_active',['../handler_8cc.html#a258ab9e0f53bf7ca6ceff4985b713cc9',1,'set_active(GtkWidget *widget, gpointer user_data):&#160;handler.cc'],['../handler_8h.html#a258ab9e0f53bf7ca6ceff4985b713cc9',1,'set_active(GtkWidget *widget, gpointer user_data):&#160;handler.cc']]],
  ['sintetico',['SINTETICO',['../struttura__dati_8h.html#a0c12af1750520ca1d5e0a1b120ed33b7a6846ea149ed5fe29f199e562567a1ddb',1,'struttura_dati.h']]],
  ['socio',['socio',['../structgiocatore__t.html#ab483a08573f49ac1b96761f869921826',1,'giocatore_t']]],
  ['socio_5ftoggle',['socio_toggle',['../handler_8cc.html#a1327446bd6ffbd129400ab552dfba9d0',1,'socio_toggle(GtkToggleButton *button, gpointer user_data):&#160;handler.cc'],['../handler_8h.html#a1327446bd6ffbd129400ab552dfba9d0',1,'socio_toggle(GtkToggleButton *button, gpointer user_data):&#160;handler.cc']]],
  ['stringa',['stringa',['../struttura__dati_8h.html#adc042033824a4d30262dea3d11937921',1,'struttura_dati.h']]],
  ['stringa_5forario',['STRINGA_ORARIO',['../handler_8cc.html#a95a01084740ad1073c35012600beada7',1,'handler.cc']]],
  ['struttura_5fdati_2eh',['struttura_dati.h',['../struttura__dati_8h.html',1,'']]]
];
