var searchData=
[
  ['id',['ID',['../structgiocatore__t.html#a2284034bca0df79f2d06364347e9d75b',1,'giocatore_t']]],
  ['indirizzo',['indirizzo',['../structcircolo__t.html#a2328697f2d980b0e400944e7340aeade',1,'circolo_t']]],
  ['interfaccia',['INTERFACCIA',['../ACE_8cc.html#ab656ac9f120982728865eddcf67088f1',1,'ACE.cc']]]
];
