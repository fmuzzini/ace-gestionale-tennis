var searchData=
[
  ['giocatori',['giocatori',['../structcircolo__t.html#aa17088e0fc000cfbc4c6b08c0c18cef2',1,'circolo_t']]],
  ['giocatori_5fdir',['GIOCATORI_DIR',['../file__IO_8cc.html#a113e87d03f38fe75cedb3d5709ae9282',1,'file_IO.cc']]]
];
