var searchData=
[
  ['socio',['socio',['../structgiocatore__t.html#ab483a08573f49ac1b96761f869921826',1,'giocatore_t']]]
];
