var searchData=
[
  ['campo_5ft',['campo_t',['../structcampo__t.html',1,'']]],
  ['circolo_5ft',['circolo_t',['../structcircolo__t.html',1,'']]]
];
