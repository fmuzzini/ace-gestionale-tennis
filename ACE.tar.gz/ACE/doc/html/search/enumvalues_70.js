var searchData=
[
  ['prenotata',['PRENOTATA',['../handler_8cc.html#ad2ef6a61f674ffd893c018201b796901a650770b03fcc1dfe25b5dc72d7bb97e8',1,'handler.cc']]]
];
