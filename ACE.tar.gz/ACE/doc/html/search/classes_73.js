var searchData=
[
  ['socio_5ft',['socio_t',['../structsocio__t.html',1,'']]]
];
