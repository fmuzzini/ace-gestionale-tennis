var searchData=
[
  ['giocatore',['GIOCATORE',['../struttura__dati_8h.html#add29541da10dc64656b40be2bf60fae1a1ea8fc2065f271f15a168433715e2b31',1,'struttura_dati.h']]]
];
