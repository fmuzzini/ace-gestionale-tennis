var searchData=
[
  ['cerca_5flista_5fint',['cerca_lista_int',['../accesso__dati_8h.html#a8c471a7dcca8667fd9f4019c9fe2e40f',1,'accesso_dati.h']]]
];
