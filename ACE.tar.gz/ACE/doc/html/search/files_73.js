var searchData=
[
  ['struttura_5fdati_2eh',['struttura_dati.h',['../struttura__dati_8h.html',1,'']]]
];
