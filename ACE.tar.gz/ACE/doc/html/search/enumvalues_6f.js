var searchData=
[
  ['outdoor',['OUTDOOR',['../struttura__dati_8h.html#ad0f5a2191c29d4cd4c52506513493755a8c38e218bbbd030490bf90a71baad2b9',1,'struttura_dati.h']]]
];
