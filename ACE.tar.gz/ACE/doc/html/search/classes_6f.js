var searchData=
[
  ['ora_5ft',['ora_t',['../structora__t.html',1,'']]]
];
